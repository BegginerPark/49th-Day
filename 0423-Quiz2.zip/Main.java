import java.util.*;

class Main {
  public static void main(String[] args) {
    Scanner sc = new Scanner(System.in);
    Random rand = new Random();
    // Random rand = new Random();
    
    //5-5,6
    // System.out.print("x = ");
    // int x = sc.nextInt();
    // System.out.print("y = ");
    // int y = sc.nextInt();
    // System.out.print("z = ");
    // int z = sc.nextInt();
    // double avg = (x+y+z)/3.0;
    // System.out.println("x,y,z의 평균값은" + avg + " 입니다.");

    //5-7
    // int a;
    // a = (int)10.0;
    // System.out.print(a);

    // 5-8
    // System.out.println("float       int");
    // System.out.println("----------------");
    // float x = 0.0F;
    // for (int i = 0; i <= 1000; i++, x += 0.001F) {
    //   System.out.printf("%10.7f    %10.7f%n", x, (float)i/1000);
    // }
    

    //6-1
    // double[] a = new double[5];

    // for (int i = 0; i < a.length; i++) {
    //   System.out.println("a[" + i + "] = " + a[i]);
    // }
    
    
    //6-2
    // int[] a = new int[5];

    // for (int i = 5; i <= 0; i--) {
      
    //   System.out.println("a[" + i + "] = " + (5-i));
    // }

    //6-6
    // System.out.print("요소 수");
    // int n = sc.nextInt();
    // int[] a = new int[n];

    // for (int j = 0; j < a.length; j++) {
    //   System.out.print("a[" + j + "] =" );
    //   a[j] = sc.nextInt();
    // }
    // System.out.println("a ={");
    // for (int i = 0; i < a.length; i++) {
    //   System.out.println(a[i] + ", ");
    // }
    // System.out.print(a[n-1]+"}");

    //6-7
    // System.out.print("사람의 수를 입력하세요: ");
    // int n = sc.nextInt();

    // int[] a = new int[n];
    // double sum = 0;
    

    // for (int i = 0; i < a.length; i++) {
    //   System.out.print((i+1)+"번의 점수: ");
    //   a[i] = sc.nextInt();
    //   sum += a[i];
    // }

    // int max = a[0];
    // for(int i = 0; i < a.length; i++) {
    //   if (a[i] > max) {
    //     max = a[i];
    //   }
    // }
    
    // int min = a[0];
    // for(int i = 0; i < a.length; i++) {
    //     if (a[i] <= min) {
    //     min = a[i];
    //   }
    // }

    // System.out.println("합계는 총 " + sum + "점 입니다.");
    // System.out.println("평균은 " + (sum/n) + "점 입니다.");
    // System.out.println("최고점은 " + max  + "점 입니다.");
    // System.out.println("최저점은 " + min + "점 입니다.");
    
    // // 6-8
    // System.out.print("요소 수: ");
    // int n = sc.nextInt();
    // int[] a = new int[n];

    // for (int j = 0; j < n; j++) {
    //   System.out.print("a[" + j + "] = ");
    //   a[j] = sc.nextInt();
    // }
    
    // System.out.print("찾는 숫자: ");
    // int s = sc.nextInt();

    // for (int i = 0; i < a.length; i++) {
    //   if (a[i] == s) {
    //     System.out.println("그 값은 " + "a["+ i +"]" + "에 있습니다.");
    //   }
    // }

    // 6-10
    // System.out.print("요소 수: ");
    // int n = sc.nextInt();
    // int[] a = new int[n];


    // for(int i = 0; i < a.length; i++) {
    //   a[i] = 1+ rand.nextInt(10);
    //   System.out.println("a[" + i + "] = " + a[i]);
    // }

    //6-11
    // System.out.print("요소 수: ");
    // int n = sc.nextInt();
    // int[] a = new int[n];
  
    // for (int i = 0; i < a.length; i++) {
    //   a[i] =1 + rand.nextInt(10);
    //   for (int k = 0; k < i; k++) {
    //     if (a[k] == a[i]) {
    //       a[i] =1 + rand.nextInt(10);
    //     }
    //   }
    //     System.out.println("a[" + i + "] = " + a[i]);
    // }

    // for (int j = 1; j < n; j++) {
    //   do {
    //     a[j] = 1 + rand.nextInt(10);
    //   } while (a[j] == a[j-1]);
    // }

    // for (int j = 0; j < n; j++) {
    //   System.out.println("a[" + j + "] = " + a[j]);
    // }


    //6-12
    // int n = 0;

    // do {
    //   System.out.print("요소 수: ");
    //   n = sc.nextInt();
    // } while (n >10);

    // int[] a = new int[n];

    // for(int i = 0; i < n; i++) {
    //   int k;
    //   do {
    //     k = 0;
    //     a[i] = 1 + rand.nextInt(10);
    //       for (k = 0; k < i; k++) {
    //         if (a[i] == a[k]) break;
    //    }
    //   } while (k < i);
    // }

    // for (int j = 0; j < n; j++) {
    //   System.out.println("a[" + j + "] = " + a[j]);
    // }

    //6-13
    // System.out.print("요소 수: ");
    // int n = sc.nextInt();
    // int[] a = new int[n];

    // for (int j = 0; j < n; j++) {
    //   System.out.print("a[" + j + "] = ");
    //   a[j] = sc.nextInt();
    // }

    // System.out.println("요소를 섞었습니다. ");
    // for (int i = 0; i < n; i ++) {
    //   int x = rand.nextInt(n);
    //   int y = rand.nextInt(n);
    //   int t = a[x];
    //   a[x] = a[y];
    //   a[y] = t;
    // }

    // for (int j = 0; j < n; j++) {
    //   System.out.println("a[" + j + "] = " + a[j]);
    // }

    //6-14
    //    System.out.print("요소 수: ");
    // int n = sc.nextInt();
    // int[] a = new int[n];
    // int[] b = new int[n];

    // for (int j = 0; j < n; j++) {
    //   System.out.print("a[" + j + "] = ");
    //   a[j] = sc.nextInt();
    // }

    // for(int i = 0; i < n ; i++) {
    //   b[i] = a[n-i-1];
    // }

    //  for (int j = 0; j < n; j++) {
    //   System.out.println("b[" + j + "] = " + b[j]);
    // }


    //6-15
    String[] months = {
      "Jan","Feb","Mar","Apr","May","Jun","July","Aug","Sep","Oct","Nov","Dec"
    };
    int re = 0;
    System.out.println("해당 월의 영어 단어를 입력하시오. 첫 글자는 대문자, 나머지는 소문자로 입력하요. ");
  
    do {
    int month = 1 + rand.nextInt(12);
    while(true) {
      System.out.print(month + "월 : ");
      String s = sc.next();
      if(s.equals(months[month-1])) break;
      System.out.println("틀렸습니다.");
    }
      System.out.println("정답입니다.");
      System.out.print("다시 한번? 1...Yes/0... No:0");
    }while (re == 1);
    
  






  }
}